# Portfolio and Resume Analysis

## Current Portfolio (https://guriboy-6fupko.manus.space)

### Design Elements:
- Dark blue/navy gradient background
- Modern, clean layout with good spacing
- Animated profile image with border
- Stats cards showing: 92M+ Users, 500+ Interviews, 28+ Hackathons, 10+ Years Exp
- Scrolling ticker with achievements
- Navigation: About, Projects, Hackathons, Leadership, Contact
- Theme toggle button
- Download Resume and View Projects CTAs
- Social links: GitHub, LinkedIn, Email
- "Made with Manus" badge

### Content Sections:
1. Hero section with tagline "Building Legendary Apps at the Edge of iOS & AI"
2. Career Journey section
3. Companies: PayPal (2019-Present), Google Stadia (2018-2019), Morgan Stanley (2016-2018), Parabit Systems (2017-2018)
4. Key achievements and technologies listed

## Resume Content (3 pages)

### Page 1:
- Header with profile photo and QR code for portfolio
- Name: Gurinder Singh
- Title: Staff Software iOS & AI/ML Engineer
- Contact: Portfolio, LinkedIn, gsingh622@yahoo.com
- Career Summary highlighting 10+ years, patent-holder, 90M+ users, 28+ hackathons, 2x 1st place wins
- Stats banner: 90M+ Users Impacted, 28+ Hackathons, 2x 1st Place Wins, Patent Holder
- Core Skills in grid layout:
  - Languages & Frameworks
  - AI/ML Stack
  - Mobile Systems
  - Cloud & Infrastructure
  - Dev Practices
  - Creative Tooling

### Page 2:
- Experience section with PayPal/Venmo (2020-Present)
  - AI/ML Evolution & Technical Innovation (2023-Present)
  - Team Mercury project details
  - AI/ML Implementation & Automation (2024)
  - iOS Engineering Excellence & Business Impact
  - Major Product Launches & Partnerships
  - iOS Innovation & Patents
  - Technical Leadership
- Google Stadia (July 2019 - 2020)
- Morgan Stanley (April 2018 - July 2019)

### Page 3:
- Technical Leadership & Team Building
- Hackathon Achievements & Innovation
  - MLH @ Bloomberg London (2017) - 1st Place
  - Devcamp NYC (2016) - 1st Place
  - HackZurich (2018) - Finalist
- Mentorship & Judging
- Cultural Impact & Community Leadership
- Recognition & Awards
- Education: New York City College of Technology, Brooklyn - BS in Computer Systems (Deferred) 2012-2016

## Key Themes:
- iOS & AI/ML expertise
- Large-scale impact (92M+ users)
- Patent holder (QR Code Widget)
- Technical leadership and mentorship
- Hackathon success
- Community building (Interfaith ERG, Sikh community)
- Innovation and cutting-edge technology
