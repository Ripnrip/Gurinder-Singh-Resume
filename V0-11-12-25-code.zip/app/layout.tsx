import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Gurinder Singh - Staff iOS & AI/ML Engineer",
  description:
    "Staff iOS & AI/ML Engineer with over a decade of experience scaling applications for millions of users. Patent-holder and technical leader specializing in bridging cutting-edge AI/ML with practical mobile solutions.",
    generator: 'v0.app'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>{children}</body>
    </html>
  )
}
